package Instrument.VirtualGuitar;

import java.awt.Color;

import javax.swing.JPanel;

//Good luck dong-jae!
public class VirtualNothing extends JPanel {
	public VirtualNothing() {
		setBackground(Color.black);
	}
}
